tar -cf logs_backup$date ~/blobmount/pma/logs/*.log ~/blobmount/crs/logs/*.log ~/blobmount/tba/logs/*.log
rm ~/blobmount/pma/logs/*.log 
rm ~/blobmount/crs/logs/*.log
rm ~/blobmount/tba/logs/*.log
