#!/bin/bash


### Check if we have anything mounted 


sudo blobfuse2 mount all ../../teamsupport1/blobmount --config-file=../blobconfig/config_team01.yml
sudo blobfuse2 mount all ../../teamsupport2/blobmount --config-file=../blobconfig/config_team02.yml
sudo blobfuse2 mount all ../../teamsupport3/blobmount --config-file=../blobconfig/config_team03.yml
