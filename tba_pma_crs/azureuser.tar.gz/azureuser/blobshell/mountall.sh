#!/bin/bash


### Check if we have anything mounted 


sudo blobfuse2 mount all ~/blobmount --config-file=../blobconfig/config.yml
