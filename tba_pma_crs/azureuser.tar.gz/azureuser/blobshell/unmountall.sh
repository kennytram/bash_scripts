sudo blobfuse2 unmount all
rm -rf ~/blobmount/*
