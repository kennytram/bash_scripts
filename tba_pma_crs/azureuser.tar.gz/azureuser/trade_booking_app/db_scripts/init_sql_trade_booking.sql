Use opscodb;
GO

CREATE SCHEMA TradeBooking;
GO

CREATE TABLE TradeBooking.Trades (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    TradeDate DATE NOT NULL,
    TradeTime TIME NULL,
    ClientCode VARCHAR(50) NOT NULL,
    ClientTradeId INT NOT NULL,
    SecurityName VARCHAR(255) NULL,
    Symbol VARCHAR(50) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    Exchange VARCHAR(100) NULL,
    Quantity BIGINT NOT NULL,
    Broker VARCHAR(100) NOT NULL,
    Way CHAR(1) NULL CHECK (Way IN ('B', 'S')),
    Trader VARCHAR(50) NULL,
    SecurityType VARCHAR(10) NULL,
    TradeStatus VARCHAR(20) NOT NULL DEFAULT 'Booked' CHECK (TradeStatus IN ('Booked', 'Cancelled')),
	Comment VARCHAR(50) NULL,
    InsertTimeStamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_trade UNIQUE (ClientTradeId, TradeDate, ClientCode)
);
GO

CREATE TABLE TradeBooking.RepoTrades (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TradeDate DATE NOT NULL,
    TradeTime TIME NULL,
    ClientTradeId INT NOT NULL,
    SecurityName VARCHAR(255) NULL,
    ClientCode VARCHAR(50) NOT NULL,
    Nominal DECIMAL(18, 2) NOT NULL,
    Currency VARCHAR(10) NOT NULL,
    CollatType VARCHAR(10) NOT NULL,
    Instrument_Code VARCHAR(50) NULL,
    Price DECIMAL(10, 2) NOT NULL,
    Quantity BIGINT NOT NULL,
    Fee DECIMAL(5, 2) NULL,
    StartDate DATE NOT NULL,
    MaturityDate DATE NOT NULL,
    Way CHAR(1) NULL CHECK (Way IN ('B', 'S')),
    Trader VARCHAR(50) NULL,
    SecurityType VARCHAR(10) NULL,
    TradeStatus VARCHAR(20) NOT NULL DEFAULT 'Booked' CHECK (TradeStatus IN ('Booked', 'Cancelled')),
	Comment VARCHAR(50) NULL,
    InsertTimeStamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT UC_RepoTrade UNIQUE (ClientTradeId, TradeDate, ClientCode)
);
GO

CREATE TABLE TradeBooking.LoanTrades (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TradeDate DATE NOT NULL,
    TradeTime TIME NULL,
    ClientTradeId INT NOT NULL,
    ClientCode VARCHAR(50) NOT NULL,
    Currency VARCHAR(10) NULL,
	FacilityType varchar(20) NULL,
	FacilityStartDate date NOT NULL,
	FacilityMaturityDate date NOT NULL,
	SNCRating varchar(2) NOT NULL,
	GrossAmount decimal(20, 2) NULL,
	NetAmount decimal(20, 2) NULL,
	UsedAmount decimal(20, 2) NULL,
    TradeStatus VARCHAR(20) NOT NULL DEFAULT 'Booked' CHECK (TradeStatus IN ('Booked', 'Cancelled')),
	Comment VARCHAR(50) NULL,
    InsertTimeStamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT UC_LoanTrade UNIQUE (ClientTradeId, TradeDate, ClientCode)
);
GO

-- Create the AuthorizedClients table
CREATE TABLE TradeBooking.AuthorizedClients (
    AuthorizationId INT PRIMARY KEY IDENTITY(1,1),
    ClientCode NVARCHAR(50) NOT NULL,
    BusinessDate DATE NOT NULL,
    KYC_Status CHAR(1) NOT NULL CHECK (KYC_Status IN ('Y', 'N')),
    RISK_Status CHAR(1) NOT NULL CHECK (RISK_Status IN ('Y', 'N')),
    ModifUser NVARCHAR(50) NOT NULL,
    InsertTimeStamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Insert some initial data
INSERT INTO TradeBooking.AuthorizedClients (ClientCode, BusinessDate, KYC_Status, RISK_Status, ModifUser)
VALUES 
('ADDL87', GETDATE(), 'Y', 'Y', 'admin'), 
('ADKC09', GETDATE(), 'Y', 'N', 'admin'),
('ABDD99', GETDATE(), 'N', 'Y', 'admin'),
('APPC12', GETDATE(), 'Y', 'Y', 'admin'),
('ABDD91', GETDATE(), 'Y', 'Y', 'admin'),
('ABDD90', GETDATE(), 'Y', 'Y', 'admin'),
('ADDE98', GETDATE(), 'Y', 'Y', 'admin'),
('ACVD53', GETDATE(), 'Y', 'Y', 'admin'),
('ACDT32', GETDATE(), 'Y', 'Y', 'admin'),
('ADVF33', GETDATE(), 'Y', 'Y', 'admin'),
('ADFF22', GETDATE(), 'Y', 'Y', 'admin'),
('ADCC12', GETDATE(), 'Y', 'Y', 'admin');
GO
