#!/bin/bash

# Directory where the log files are stored
LOG_DIR="../logs"
PROGRAM_TO_STOP="monitor_and_load_client_trades"

# Get the most recent log file
LOG_FILE=$(ls -t ${LOG_DIR}/$PROGRAM_TO_STOP_*.log 2>/dev/null | head -n 1)

# Find the process ID of the monitor.py script
PID_PY=$(pgrep -f $PROGRAM_TO_STOP.py)

# Check if the process is running and stop it
if [ -n "$PID_PY" ]; then
    kill "$(echo $PID_PY | awk '{print $1}')"
    if [ $? -eq 0 ]; then
        echo "Successfully stopped $PROGRAM_TO_STOP.py (PID: $PID_PY)." | logger -s 2>>$LOG_FILE
    else
        echo "Failed to stop $PROGRAM_TO_STOP.py (PID: $PID_PY)." | logger -s 2>>$LOG_FILE
    fi
else
    echo "No running process found for $PROGRAM_TO_STOP.py."
fi
