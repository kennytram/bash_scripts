#!/bin/sh

# Values to update for each application
application_name="trade_booking_app"
python_script_1="./app/monitor_and_load_client_trades.py"

# Log the start of the script
echo "Starting $application_name script"

# Run for specific dates
# run_dates=("20240610" "20240611" "20240612" "20240613" "20240614")

# Or by default run for current business date
business_date=$(python3 ./utils/get_business_date.py)
if [ $? -ne 0 ]; then
        echo "Error: get_business_date.py failed: $business_date"
        exit 1
    fi
run_dates=($business_date)


mode="local"
# Run the script for each date in the list
for date in "${run_dates[@]}"; do
    #Run the application script
    python3 $python_script_1 "$date" "$mode"
    echo "Python script $python_script_1 for date $date exited with status $?."
    if [ $? -ne 0 ]; then
        echo "Error: Python script $python_script_1 for date $date failed."
        exit 1
    fi
done

# Log the end of the script
echo "Finished $application_name script"