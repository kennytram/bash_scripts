#!/bin/bash

# Values to update for each application
docker_container_name="tradebooking"
docker_image_name="trade_booking_app"
docker_network_name="opsco_network"
docker_file_path="docker/Dockerfile"

# Make sure no issue with file format
dos2unix ../*/*

# Build the Docker image
docker build -f $docker_file_path -t $docker_image_name .

# Kill running container
docker kill $docker_container_name

# Run the Docker container and replace existing automatically
docker run --rm --name $docker_container_name --network $docker_network_name -d $docker_image_name

# Display all Containers
docker ps -a

# Display network
docker network inspect $docker_network_name

# Display logs after 10 seconds
sleep 10
Docker logs $docker_container_name

# Display Database container IP
#db_ip=$(docker inspect opscodb | grep '"IPAddress"' | grep -o -E '[0-9.]{7,15}' | head -n 1)
#echo $db_ip