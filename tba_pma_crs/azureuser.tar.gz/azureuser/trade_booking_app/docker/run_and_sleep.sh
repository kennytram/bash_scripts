#!/bin/bash

# Check if APP_FEATURE_NAME argument is provided
if [ -z "$1" ]; then
  echo "Error: APP_FEATURE_NAME argument is missing. Example: run_tba_monitor_and_load_client_trades"
  echo "Usage: $0 <APP_FEATURE_NAME>"
  exit 1
fi

# Parse command-line argument for APP_FEATURE_NAME
APP_FEATURE_NAME=$1

# Run the launcher script (choose which part of the application to run in a container)
# bash scripts/$APP_FEATURE_NAME.sh

# LOCAL CONTAINER: Or force all runs in the same container
bash scripts/run_tba_load_sod_positions.sh
bash scripts/run_tba_monitor_and_load_trades.sh
# bash scripts/run_tba_eod_extract_loan_trades.sh
# bash scripts/run_tba_eod_extract_repo_trades.sh
# bash scripts/run_tba_eod_extract_trades.sh

echo "Sleep for 5 minutes (enough time to check logs & files on the Container)..."
sleep 3000