# Client Trade booking application (Ctrade)

The **Trade Booking Application** manages the booking of trade and repo trade data for investment banking, including ingestion, validation, booking, and end-of-day reporting.

## Features

- **Ingestion and Validation**: Supports CSV file ingestion, performs data validation, checks date formats, client authorization, and data consistency.
- **Trade Booking**: Books valid trade and repo trade data into database tables, ensuring data integrity.
- **End-of-Day Reporting**: Generates detailed EOD reports for trades and repo trades, with automated file transfers.
- **Logging**: Detailed, timestamped logs for all operations, transferred to remote servers for monitoring.
- 
---
## Directory Structure

```plaintext
trade_booking_app/
│
├── config/
│   └── config.py
├── data/
│   ├── input/
|   │   ├── working/
|   │   └── processed/
│   └── output/
├── logs/
├── scripts/
│   ├── run_trade_booking_app.ksh
│   └── stop_trade_booking_app.sh
├── db_scripts/
│   └── init_sql_trade_booking.sql
├── utils/
│   ├── db_utils.py
│   ├── file_utils.py
│   └── sanity_checks.py
├── monitor.py
├── load_client_trades.py
├── eod_trade_reporter.py
├── build_and_run_docker.sh
├── docker_compose.yml
├── Dockerfile
└── README.md
```

---
## Processes

### `config.py`
Contains all the configuration settings for the application, including database connection details, file paths, and fields to extract for reports.

### `monitor.py`
Monitors the input folder for new client trade files and move them to the `input/working` folder for processing. 
Then calls `load_client_trades.py` with each client trade file. 

### `load_client_trades.py`
Main function to handle trade booking operations.
- Retrieves and validates input files.
- Connects to the database and checks client authorization.
- Performs data validation and inserts valid trades into the database.
- Logs all operations and errors.

### `eod_trade_reporter.py`
Extracts EOD trades reports for `Trades`, `RepoTrades` and `LoanTrades` in the `data/output` folder.
This reports will feed the `Position Management Application` (https://github.com/OPS-CO-Solutions/position_management_app)

### `utils/db_utils.py`
Contains utility functions for database operations.
- Connects to the database using SQLAlchemy.
- Handles trades insertion and extraction.

### `utils/file_utils.py`
Contains utility functions for file operations.
- Reads data from CSV files.
- Writes data to CSV files.

### `utils/sanity_checks.py`
Performs data functionnal validation. 

---
## Local Setup
1. Clone the repository.
2. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run monitor.py

---
## Quick Docker Build and Run Command
1. Clone the repository.
2. Build and run the container
```sh
cd trade_booking_app/
./build_and_run_docker.sh
```
