import subprocess
import pandas as pd
import os
import logging
import shutil
import sys

# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'utils'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'azure'))

from db_utils import load_data_to_table, truncate_and_load_data_to_table
from move_blob_input_files import move_blob
from config import CONFIG


def read_and_load_file_to_db (load_date, file_config, table, schema, loading_type):
    logging.info(f'Preparing to read file {file_config} with date {load_date}')
    file_name = file_config.format(date=load_date)
    local_file_path = os.path.join(CONFIG['input_files']['local_input_folder'], file_name)
    file_data = read_csv_file(local_file_path)

    if file_data is not None:
        logging.info(f'Data read from {local_file_path} and ready to load in table {table}: {file_data}')
        # Always add business date column
        #file_data['BusinessDate'] = load_date
        if loading_type == 'trunc':
            truncate_and_load_data_to_table(file_data, table, schema)
        else: 
            load_data_to_table(file_data, table, schema)


def read_csv_file(file_path):
    try:
        return pd.read_csv(file_path, encoding='latin1')
    except Exception as e:
        logging.error(f"Error reading CSV file {file_path}: {e}")
        return None

def write_csv_file(data, file_path):
    try:
        data.to_csv(file_path, index=False)
        logging.info(f"Data written to CSV file {file_path}")
    except Exception as e:
        logging.error(f"Error writing CSV file {file_path}: {e}")

def write_to_excel(data, file_path):
    try:
        with pd.ExcelWriter(file_path, engine='xlsxwriter') as writer:
            data.to_excel(writer, index=False, sheet_name='Sheet1')
            logging.info(f"Data successfully written to {file_path}")
    except Exception as e:
        logging.error(f"Error writing data to Excel file '{file_path}': {e}")


def initialize_log_file(log_file_name):
    log_file_path = os.path.join(CONFIG['local_paths']['log_folder'], log_file_name)
    print(log_file_path)

    logging.basicConfig(
                        level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S',
                        handlers=[
                                logging.StreamHandler(sys.stdout),  # Print to console
                                logging.FileHandler(log_file_path)  # Write to log file
                            ])
    logging.info("Log file initialized.")

def list_input_files():
    local_input_folder = CONFIG['input_files']['local_input_folder']
    try:
        file_list = os.listdir(local_input_folder)
        logging.info(f"Listed files in local folder {local_input_folder}: {file_list}")
        return file_list
    except Exception as e:
        logging.error(f"Error listing files in {local_input_folder}: {e}")
        exit(1)


def move_trade_file_to_working_folder(mode, file_name):
    try:
        local_input_path = os.path.join(CONFIG['input_files']['local_input_folder'], file_name)
        local_working_path = os.path.join(CONFIG['local_paths']['local_working_folder'], file_name)
        shutil.move(local_input_path, local_working_path)
        logging.info(f"Input file {file_name} moved to {local_working_path}.")
    except Exception as e:
        logging.error(f"Error moving file {file_name} to {local_working_path}: {e}")
        exit(1)

    if mode == 'remote':
        try:
            app_container_name = CONFIG['azure_config']['app_container_name']
            remote_input_file_path = os.path.join(CONFIG['azure_config']['input_path'], file_name)
            remote_working_file_path = os.path.join(CONFIG['azure_config']['working_path'], file_name)
            # Move the remote file 
            move_blob(app_container_name, remote_input_file_path, remote_working_file_path)      
        except Exception as e:
            logging.error(f"Error moving file in {remote_working_file_path}: {e}")  
            exit(1)  
    elif mode != 'local':
        logging.error(f"Mode '{mode}' not supported")
        exit(1)

def move_trade_file_to_processed_folder(mode, file_name):
    try:
        local_working_path = os.path.join(CONFIG['local_paths']['local_working_folder'], file_name)
        local_processed_path = os.path.join(CONFIG['local_paths']['local_processed_folder'], file_name)
        shutil.move(local_working_path, local_processed_path)
        logging.info(f"working file {file_name} moved to {local_processed_path}.")
    except Exception as e:
        logging.error(f"Error moving file {file_name} to {local_processed_path}: {e}")
        exit(1)

    if mode == 'remote':
        try:
            app_container_name = CONFIG['azure_config']['app_container_name']
            remote_working_file_path = os.path.join(CONFIG['azure_config']['working_path'], file_name)
            remote_processed_file_path = os.path.join(CONFIG['azure_config']['processed_path'], file_name)
            # Move the remote file 
            move_blob(app_container_name, remote_working_file_path, remote_processed_file_path)      
        except Exception as e:
            logging.error(f"Error moving file in {remote_processed_file_path}: {e}")  
            exit(1)  
    elif mode != 'local':
        logging.error(f"Mode '{mode}' not supported")
        exit(1)


def save_successfully_inserted_data(data, input_file_path):
    global log_time_stamp
    output_file_name = os.path.basename(input_file_path).replace('.csv', f'_{log_time_stamp}_booked.csv')
    output_file_path = os.path.join(CONFIG['output_files']['output_folder'], output_file_name)
    data.to_csv(output_file_path, index=False)
    logging.info(f"Successfully inserted data saved to {output_file_path}")
    # save_to_remote_server(output_file_path, output_file_name)
  
    
def parse_filename(file_name):
    name_parts = file_name.split('_')
    client_code = name_parts[0]
    trade_type = name_parts[1]
    trade_date = name_parts[2]
    file_number = name_parts[3].split('.')[0]
    return client_code, trade_type, trade_date, file_number