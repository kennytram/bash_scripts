import os
import sys
import pandas as pd
import pyodbc
from datetime import datetime, date
import decimal
import logging

# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from config import CONFIG


def connect_to_db_sqlalchemy():
    try:
        engine = create_engine(CONFIG['db_config']['db_url'],
            connect_args={
                "timeout": 10  # Set the timeout to 10 seconds
            })
        Session = sessionmaker(bind=engine)
        session = Session()
        logging.info("Connected to database successfully.")
        return engine, session
    except Exception as e:
        logging.error(f"ErrorCode: 200, Error connecting to database: {e}")
        sys.exit(1)  # Exit the script with error code 1


def load_data_to_table(data, table_name, schema):
    logging.info(f"Loading data into {table_name}...")
    # Connect to DB
    engine, session = connect_to_db_sqlalchemy()

    try:
        query_result = data.to_sql(table_name, engine, schema=schema, if_exists='append', index=False)
        logging.info(f"data.sql: {query_result}")
        logging.info(f"Data loaded successfully into {table_name}.")
        session.commit()
    except Exception as e:
        logging.error(f"ErrorCode: 201, Error loading data into {table_name}: {e}")
        sys.exit(1)  # Exit the script with error code 1
    finally:
        session.close()

def insert_trades_to_db(data, table_name, schema):
    logging.info(f"Loading data into {table_name}...")
    # Connect to DB
    engine, session = connect_to_db_sqlalchemy()
    
    for index, row in data.iterrows():
        try:
            if table_name == "Trades" and is_short_sell_trade(row['TradeDate'], row['ClientCode'], row['Symbol'], row['Currency'], row['Quantity']):
                logging.error(f"ErrorCode: 209, Sell trade {row['ClientTradeId']} rejected due to insufficient available position for client {row['ClientCode']} on TradeDate {str(row['TradeDate'])}")
            else:   
                row_df = row.to_frame().T
                row_df.to_sql(table_name, engine, schema=schema, if_exists='append', index=False)
                logging.info(f"Row {index} inserted: {row_df.to_dict(orient='records')}")
                logging.info(f"Successfully inserted ClientTradeId {row['ClientTradeId']} on TradeDate {str(row['TradeDate'])}.")
                session.commit()
                # successfully_inserted_data = pd.concat([successfully_inserted_data, row_df], ignore_index=True)
        except pyodbc.IntegrityError as ie:
            logging.error(f"ErrorCode: 208, Integrity error inserting ClientTradeId {row['ClientTradeId']} on TradeDate {str(row['TradeDate'])}: {ie}")
        except Exception as e:
            logging.error(f"ErrorCode: 201, Error loading data into {table_name}: {e}")
            sys.exit(1)  # Exit the script with error code 1
        finally:
            session.close()


def truncate_and_load_data_to_table(data, table_name, schema):
    # Connect to DB
    engine, session = connect_to_db_sqlalchemy()

    logging.info(f"Truncate table {schema}.{table_name} attempt")
    try: 
        session.execute(text(f"TRUNCATE TABLE {schema}.{table_name};"))
        session.commit()
        logging.info(f"Truncate table successfully {schema}.{table_name}.")
    except Exception as e:
        logging.error(f"ErrorCode: 202, Error truncate table {schema}.{table_name}: {e}")
        sys.exit(1)  # Exit the script with error code 1

    load_data_to_table(data, table_name, schema)


def extract_data(query, params=None):
    logging.info(f"Extracting data query: {query}.")
    # Connect to DB
    engine, session = connect_to_db_sqlalchemy()

    try:
        result = session.execute(text(query), params)
        logging.info(result)
        data = result.fetchall()
        column_names = result.keys()
        df = pd.DataFrame(data, columns=column_names)
        return df
    except Exception as e:
        logging.error(f"ErrorCode: 203, Error executing query: {e}")
        sys.exit(1)  # Exit the script with error code 1
    finally:
        session.close()
    
    
def execute_stored_procedure(schema, procedure_name, params=None):
    logging.info(f"Executing stored procedure: {procedure_name}")
    engine, session = connect_to_db_sqlalchemy()

    try:
        if params:
            session.execute(text(f"EXEC {schema}.{procedure_name} '{params}'"))
        else:
            session.execute(text(f"EXEC {schema}.{procedure_name}"))
        session.commit()
        logging.info(f"Stored procedure '{schema}.{procedure_name}' executed successfully.")
    except Exception as e:
        logging.error(f"ErrorCode: 204, Error executing stored procedure '{schema}.{procedure_name}': {e}")
        sys.exit(1)  # Exit the script with error code 1
    finally:
        session.close()


def execute_extract_stored_procedure(schema, procedure_name, params=None):
    logging.info(f"Executing stored procedure: {schema}.{procedure_name}")
    engine, session = connect_to_db_sqlalchemy()

    try:
        result = session.execute(text("EXEC {schema}.{procedure_name}"))
        session.commit()

        # Debugging information
        logging.info(f"Result type: {type(result)}")

        # Check if the result contains any rows
        if result.returns_rows:
            data = result.fetchall()
            column_names = result.keys()
            df = pd.DataFrame(data, columns=column_names)
            logging.info(f"Stored procedure '{schema}.{procedure_name}' executed successfully and returned data.")
            return df
        else:
            logging.info(f"Stored procedure '{schema}.{procedure_name}' executed successfully but returned no data.")
            return None
    except Exception as e:
        logging.error(f"ErrorCode: 204, Error executing stored procedure '{schema}.{procedure_name}': {e}")
        sys.exit(1)  # Exit the script with error code 1
    finally:
        session.close()


def is_client_authorized(client_code, trade_date):
    try:
        query = """
        SELECT COUNT(*) AS Count
        FROM TradeBooking.AuthorizedClients
        WHERE ClientCode = :client_code
        AND KYC_Status = 'Y'
        AND RISK_Status = 'Y'
        """

        params = {
            "client_code": client_code
        }

        result = extract_data(query, params)
        logging.info(result)
        return result['Count'].iloc[0]
    except Exception as e:
        logging.error(f"ErrorCode: 205, Error executing query: {e}")
        sys.exit(1)  # Exit the script with error code 1


def is_short_sell_trade(trade_date, client_code, symbol, currency, trade_qty):
    try:
        query = """
        SELECT COUNT(*) AS Count
        FROM TradeBooking.Positions
        WHERE ClientCode = :client_code
        AND Symbol = :symbol
        AND Currency = :currency
        AND Quantity < :trade_qty
        AND BusinessDate = :trade_date
        """

        params = {
            "client_code": client_code,
            "symbol": symbol,
            "currency": currency,
            "trade_qty": trade_qty,
            "trade_date": trade_date
        }

        result = extract_data(query, params)
        logging.info(result)
        return result['Count'].iloc[0]
    except Exception as e:
        logging.error(f"ErrorCode: 205, Error executing query: {e}")
        sys.exit(1)  # Exit the script with error code 1


def get_current_business_date():
    try:
        # Build trades extract query
        query = f"""
            SELECT BusinessDate
            FROM core.Calendar
            WHERE CurrentDate = '1'
        """
        business_date=extract_data(query)
        return business_date['BusinessDate'].iloc[0]
    except Exception as e:
        print(f"ERROR ErrorCode: 206, An error occurred in get_current_business_date(): {e}")
        sys.exit(1)  # Exit the script with error code 1
