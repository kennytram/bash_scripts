import pandas as pd
from datetime import datetime
import logging

def sanity_check(data, client_code, trade_date):
    logging.info("Starting Trades Sanity Checks...")
    valid_data = pd.DataFrame(columns=data.columns)
    errors = []

    #format dates into str instead of int
    data['TradeDate'] = data['TradeDate'].apply(lambda x: f"{x}")
    logging.info(data)

    for index, row in data.iterrows():
        #logging.info(row)
        try:
            # Check if the date is in the future
            if datetime.strptime(str(row['TradeDate']), "%Y%m%d") > datetime.now():
                errors.append(f"ErrorCode: 100, ClientTradeId {row['ClientTradeId']}: TradeDate is in the future.")
                continue

            # Check if the trade date is on a weekend
            trade_date_obj = datetime.strptime(str(row['TradeDate']), "%Y%m%d")
            if trade_date_obj.weekday() > 4:  # 5 and 6 correspond to Saturday and Sunday
                errors.append(f"ErrorCode: 101, ClientTradeId {row['ClientTradeId']}: TradeDate '{str(row['TradeDate'])}' is on a weekend.")
                continue

            # Check if the client code in any row is different than the client code in the file name
            if row['ClientCode'] != client_code:
                errors.append(f"ErrorCode: 102, ClientTradeId {row['ClientTradeId']}: ClientCode '{row['ClientCode']}' does not match client code in file name '{client_code}'.")
                continue
            
            # Check if the trade date in any row is different than the trade date in the file name
            if str(row['TradeDate']) != str(trade_date):
                errors.append(f"ErrorCode: 103, ClientTradeId {row['ClientTradeId']}: TradeDate '{str(row['TradeDate'])}' does not match trade date in file name '{trade_date}'.")
                continue

            # Check for data format issues
            try:
                datetime.strptime(str(row['TradeDate']), "%Y%m%d")
            except ValueError:
                errors.append(f"ErrorCode: 104, lientTradeId {row['ClientTradeId']}: TradeDate format is incorrect.")
                continue
            
            try:
                datetime.strptime(row['TradeTime'], "%H:%M:%S")
            except ValueError:
                errors.append(f"ErrorCode: 105, ClientTradeId {row['ClientTradeId']}: TradeTime format is incorrect.")
                continue
            
            if not isinstance(row['ClientTradeId'], int):
                errors.append(f"ErrorCode: 106, ClientTradeId {row['ClientTradeId']}: ClientTradeId format is incorrect.")
                continue
            
            if not isinstance(row['Price'], (float, int)):
                errors.append(f"ErrorCode: 107, ClientTradeId {row['ClientTradeId']}: Price format is incorrect.")
                continue
            
            if not isinstance(row['Quantity'], int):
                errors.append(f"ErrorCode: 108, ClientTradeId {row['ClientTradeId']}: Quantity format is incorrect.")
                continue

            # If all checks pass, add the row to valid_data
            valid_data = pd.concat([valid_data, row.to_frame().T], ignore_index=True)

        except Exception as e:
            logging.error(f"Error: {e}")
            continue

    logging.info("End of Trades Sanity Checks...")

    if errors:
        for error in errors:
            logging.error(error)
    
    return valid_data

def sanity_check_repo(data, client_code, trade_date):
    logging.info("Starting Trades_repo Sanity Checks...")
    valid_data = pd.DataFrame(columns=data.columns)
    errors = []
    
    #format dates into str instead of int
    data['TradeDate'] = data['TradeDate'].apply(lambda x: f"{x}")
    data['StartDate'] = data['StartDate'].apply(lambda x: f"{x}")
    data['MaturityDate'] = data['MaturityDate'].apply(lambda x: f"{x}")
    logging.info(data)

    for index, row in data.iterrows():
        #logging.info(row)

        try:
            # Check if the date is in the future
            if datetime.strptime(str(row['TradeDate']), "%Y%m%d") > datetime.now():
                errors.append(f"ErrorCode: 100, ClientTradeId {row['ClientTradeId']}: TradeDate is in the future.")
                continue
            
            # Check if the client code in any row is different than the client code in the file name
            if row['ClientCode'] != client_code:
                errors.append(f"ErrorCode: 102, ClientTradeId {row['ClientTradeId']}: ClientCode '{row['ClientCode']}' does not match client code in file name '{client_code}'.")
                continue
            
            # Check if the trade date in any row is different than the trade date in the file name
            if str(row['TradeDate']) != str(trade_date):
                errors.append(f"ErrorCode: 103, ClientTradeId {row['ClientTradeId']}: TradeDate '{str(row['TradeDate'])}' does not match trade date in file name '{trade_date}'.")
                continue

            # Check if the maturity date is before the start date
            if datetime.strptime(str(row['MaturityDate']), "%Y%m%d") < datetime.strptime(str(row['StartDate']), "%Y%m%d"):
                errors.append(f"ErrorCode: 109, ClientTradeId {row['ClientTradeId']}: MaturityDate is before StartDate.")
                continue

            # Check for data format issues
            try:
                datetime.strptime(str(row['StartDate']), "%Y%m%d")
            except ValueError:
                errors.append(f"ClientTradeId {row['ClientTradeId']}: StartDate format is incorrect.")
                continue
            
            try:
                datetime.strptime(str(row['MaturityDate']), "%Y%m%d")
            except ValueError:
                errors.append(f"ClientTradeId {row['ClientTradeId']}: MaturityDate format is incorrect.")
                continue
            
            if not isinstance(row['ClientTradeId'], int):
                errors.append(f"ErrorCode: 106, ClientTradeId {row['ClientTradeId']}: ClientTradeId format is incorrect.")
                continue
            
            # Price can be empty for repo cash
            if row['Price'] != "" and row['Price'] is not None:
                if not isinstance(row['Price'], (float, int)):
                    errors.append(f"ErrorCode: 107, ClientTradeId {row['ClientTradeId']}: Price format is incorrect.")
                    continue
            
            if not isinstance(row['Quantity'], int):
                errors.append(f"ErrorCode: 108, ClientTradeId {row['ClientTradeId']}: Quantity format is incorrect.")
                continue

            if not isinstance(row['Nominal'], (float, int)):
                errors.append(f"ErrorCode: 110, ClientTradeId {row['ClientTradeId']}: Nominal format is incorrect.")
                continue

            if not isinstance(row['Fee'], (float, int)):
                errors.append(f"ErrorCode: 111, ClientTradeId {row['ClientTradeId']}: Fee format is incorrect.")
                continue
            
            # If all checks pass, add the row to valid_data
            valid_data = pd.concat([valid_data, row.to_frame().T], ignore_index=True)

        except Exception as e:
            logging.error(f"Error: {e}")
            continue
    
    logging.info("End of Trades_repo Sanity Checks...")

    if errors:
        for error in errors:
            logging.error(error)
    
    return valid_data


def sanity_check_loan(data, client_code, trade_date):
    logging.info("Starting LoanTrades Sanity Checks...")
    try:
        valid_data = pd.DataFrame(columns=data.columns)
        errors = []

        #format dates into str instead of int
        data['TradeDate'] = data['TradeDate'].apply(lambda x: f"{x}")
        data['FacilityStartDate'] = data['FacilityStartDate'].apply(lambda x: f"{x}")
        data['FacilityMaturityDate'] = data['FacilityMaturityDate'].apply(lambda x: f"{x}")
        logging.info(data)
    except Exception as e:
        logging.error(f"Error: {e}")

    return data