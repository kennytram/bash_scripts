import os
import sys
from datetime import datetime


# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'utils'))
from db_utils import get_current_business_date

def main():
    business_date = get_current_business_date()
    try:    
        formatted_date = datetime.strptime(str(business_date), "%Y-%m-%d").strftime("%Y%m%d")
        print(formatted_date)
    except Exception as e:
        print(f"ERROR ErrorCode: 206, could not format the date {business_date} in get_business_date.py")
        sys.exit(1)

if __name__ == "__main__":
    main()
