import os

CONFIG = {
    "db_config": {
        # 'db_url': "mssql+pyodbc://sa:Database94200!@localhost:1433/opscodb?driver=ODBC+Driver+17+for+SQL+Server" # local db server
        # 'db_url': "mssql+pyodbc://sa:Database94200!@172.18.0.2:1433/opscodb?driver=ODBC+Driver+17+for+SQL+Server" # local container db server
        'db_url': "mssql+pyodbc://opsco_admin:Database94200!@banksim.database.windows.net:1433/opscodb?driver=ODBC+Driver+17+for+SQL+Server" # remote db server
        # 'db_url': "mssql+pyodbc://banksimdb01:CAVABIENALLEZLA!4@banksim.database.windows.net:1433/opscodb_01?driver=ODBC+Driver+17+for+SQL+Server" # remote db server team 1
        # 'db_url': "mssql+pyodbc://banksimdb02:CAVABIENALLEZLA!4@banksim.database.windows.net:1433/opscodb_02?driver=ODBC+Driver+17+for+SQL+Server" # remote db server team 2
        # 'db_url': "mssql+pyodbc://banksimdb03:CAVABIENALLEZLA!4@banksim.database.windows.net:1433/opscodb_03?driver=ODBC+Driver+17+for+SQL+Server" # remote db server team 3

    },
    "local_paths": {
        'log_folder': 'logs',
        'local_working_folder': 'data/input/working',
        'local_processed_folder': 'data/input/processed',
    },
    "load_position_data":{
        "Positions": {"file": "positions_{date}.csv", "loading_type": "histo"}
    },
    "input_files": {
        'local_input_folder': 'data/input',
        'client_trades': '{client}_trades_{date}_{file_number}.csv',
        'client_repo_trades': '{client}_repo_trades_{date}_{file_number}.csv',
        'client_loan_trades': '{client}_loan_trades_{date}_{file_number}.csv',
    },
    "output_files": {
        'local_output_folder': 'data/output',
        'eod_trades': 'eod_trades_{date}.csv',
        'eod_repo_trades': 'eod_repo_trades_{date}.csv',
        'eod_loan_trades': 'eod_loan_trades_{date}.csv',
        'client_trades_booked': '{client}_trades_{date}_{file_number}_{timestamp}_booked.csv',
        'client_repo_trades_booked': '{client}_repo_trades_{date}_{file_number}_{timestamp}_booked.csv'
    },
    "log_files": {
        'trade_monitoring': 'monitor_and_load_client_trades_{timestamp}.log',
        'load_client_trades': '{client}_{trade_type}_{date}_{file_number}_{timestamp}.log',
        'eod_extract_trades': 'extract_eod_trades_{timestamp}.log',
        'eod_extract_repo_trades': 'eod_extract_repo_trades_{timestamp}.log',
        'eod_extract_loan_trades': 'eod_extract_loan_trades_{timestamp}.log',
        'load_position_data': 'load_sod_positions_{timestamp}.log',
    },
    "fields_to_extract": {
        'eod_repo_trades': ['TradeDate', 'TradeTime', 'ClientTradeId', 'ClientCode', 'Nominal', 'Currency', 'CollatType', 'Instrument_Code', 'Price', 'Quantity', 'Fee', 'StartDate', 'MaturityDate'],
        'eod_trades': ['TradeDate', 'TradeTime', 'ClientCode', 'ClientTradeId', 'Symbol', 'Price', 'Exchange', 'Quantity', 'Broker', 'Way', 'Trader', 'SecurityType'],
        'eod_loan_trades': ['TradeDate', 'TradeTime', 'ClientTradeId', 'ClientCode', 'FacilityType', 'FacilityStartDate', 'FacilityMaturityDate', 'SNCRating', 'GrossAmount', 'NetAmount', 'UsedAmount']
    },
    "azure_config": {
        'account_name': 'creditriskstorage',
        'account_key': 'SaKmyJ7QjOMBIeJP/8RP9dpXRtAoNu5eOMUFBNIWMjkGeAO/FKPcmBYNyY86VgQUyi5tOu6X5aiu+AStTkMS4w==',
        # 'account_name': 'banksimstorage01',
        # 'account_key': 'IZsxydqfl8MiIPOoMbD7ftu6gTCbbUBY0tBKD0OZF45GwNRyMJM7L7IZ5iu7lJAOzaPxp8dc9NHB+ASt7mAUXg==',
        #'account_name': 'banksimstorage02',
        #'account_key': 'qM4xyLy3qQvoRCvpwLj5RAHfooPW82OK13L78lwf+pErjTX9q+cmCgbFLU6YVgfylFWIOorz5SWS+AStbO85cg==',
        #'account_name': 'banksimstorage03',
        #'account_key': 'Ka4zCEy+NwKrnR7/GoIKvpacYNWQRC4XfhH2jzxin/cjoTwSVewESpnP0uujA/8RxdGw2P4WzqrQ+AStx1ozsA==',
        'connection_string': 'DefaultEndpointsProtocol=https;AccountName={account_name};AccountKey={account_key};EndpointSuffix=core.windows.net',
        'app_container_name': 'tba',
        'log_container_name': 'banksimlogs',
        'input_path': 'data/input',
        'working_path': 'data/input/working',
        'processed_path': 'data/input/processed'
    }
}
