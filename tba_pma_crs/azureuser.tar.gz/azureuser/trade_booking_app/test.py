import subprocess
import pandas as pd
import os
from utils.db_utils import insert_data_to_db, is_client_authorized
from utils.file_utils import save_successfully_inserted_data
from utils.sanity_checks import sanity_check
import pyodbc
    
def main():  

    # Get the directory of the current script
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # Construct the full path to load_client_trades.py
    script_path = os.path.join(current_dir, "load_client_trades.py")


    result = subprocess.run(
                                ["python3", script_path, "ABBD91_repotrades_20240625_1.csv", 'local'],
                                capture_output=True,
                                text=True,
                                timeout=120
                            )
    print (result)

if __name__ == '__main__':
    main()