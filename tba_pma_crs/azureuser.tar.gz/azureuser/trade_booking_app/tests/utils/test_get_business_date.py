import unittest
from unittest.mock import patch
from datetime import datetime
import sys
from io import StringIO

# Utility class to capture print statements during testing
class CaptureOutput(list):
    def __enter__(self):
        self._stdout = sys.stdout
        sys.stdout = self._stringio = StringIO()
        return self

    def __exit__(self, *args):
        self.extend(self._stringio.getvalue().splitlines())
        sys.stdout = self._stdout

# Adjust the path for the test environment
sys.path.insert(0, '../../')

from utils.get_business_date import main

class TestGetBusinessDate(unittest.TestCase):
    @patch('utils.get_business_date.get_current_business_date')
    def test_get_business_date_success(self, mock_get_current_business_date):
        """
        Test the get_business_date script for successful date formatting.
        """
        # Mock the return value of get_current_business_date
        mock_get_current_business_date.return_value = '2024-06-10'

        with CaptureOutput() as output:
            try:
                main()
            except SystemExit:
                pass  # Ignore the SystemExit exception

        expected_date = '20240610'
        self.assertIn(expected_date, output)

    @patch('utils.get_business_date.get_current_business_date')
    def test_get_business_date_formatting_error(self, mock_get_current_business_date):
        """
        Test the get_business_date script to handle formatting errors.
        """
        # Mock the return value to something that will cause a formatting error
        mock_get_current_business_date.return_value = 'invalid_date'

        with CaptureOutput() as output:
            try:
                main()
            except SystemExit:
                pass  # Ignore the SystemExit exception

        self.assertIn("Error: could not format the date invalid_date in get_business_date.py", output)

if __name__ == '__main__':
    unittest.main()
