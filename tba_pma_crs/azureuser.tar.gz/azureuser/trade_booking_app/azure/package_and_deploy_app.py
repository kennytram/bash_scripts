import os
import zipfile
import sys
from azure.storage.blob import BlobServiceClient
# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))
from config import CONFIG

# Configuration
app_names = ["trade_booking_app"]  # List of application names
container_names = ["tba"]  # Corresponding container names
zip_file_names = ["tba.zip"]
account_name = CONFIG['azure_config']['account_name']
account_key = CONFIG['azure_config']['account_key']

connection_string = CONFIG['azure_config']['connection_string'].format(account_name=account_name, account_key=account_key)

local_paths = [os.path.abspath(f'../../{app_name}') for app_name in app_names]

def zipdir(path, ziph):
    # ziph is zipfile handle
    for root, dirs, files in os.walk(path):
        for file in files:
            ziph.write(os.path.join(root, file),
                       os.path.relpath(os.path.join(root, file), path))

def create_zip_file(local_path, zip_file_name):
    with zipfile.ZipFile(f'../../{zip_file_name}', 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipdir(local_path, zipf)
    print(f"{zip_file_name} created successfully.")
    return zip_file_name

def upload_app_to_blob(zip_file_name, container_name):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=zip_file_name)

        with open(f'../../{zip_file_name}', "rb") as data:
            blob_client.upload_blob(data, overwrite=True)
        print(f"{zip_file_name} uploaded to container {container_name} successfully.")
    except Exception as e:
        print(f"Failed to upload {zip_file_name} to container {container_name}: {e}")

def upload_run_script_to_blob(file_name, container_name):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=file_name)

        with open(f'{file_name}', "rb") as data:
            blob_client.upload_blob(data, overwrite=True)
        print(f"{file_name} uploaded to container {container_name} successfully.")
    except Exception as e:
        print(f"Failed to upload {file_name} to container {container_name}: {e}")

if __name__ == "__main__":
     for app_name, container_name, local_path, zip_file_name in zip(app_names, container_names, local_paths, zip_file_names):
        # Package the application (zip)
        create_zip_file(local_path, zip_file_name)
        
        # Deploy the application to Blob Container (from where it is used by Azure batch job run)
        upload_app_to_blob(zip_file_name, container_name)

        # Deploy the run script to Blob Container (launcher script for Azure batch job)
        upload_run_script_to_blob("run.sh", container_name)
