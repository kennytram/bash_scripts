import sys
import os
from datetime import datetime
from azure.storage.blob import BlobServiceClient

# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))
from config import CONFIG

# Configuration
local_logs_directory = "logs/"
local_output_directory = "data/output/"
account_name = CONFIG['azure_config']['account_name']
account_key = CONFIG['azure_config']['account_key']

connection_string = CONFIG['azure_config']['connection_string'].format(account_name=account_name, account_key=account_key)

# Initialize BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(connection_string)

def upload_files(container_name, local_directory, blob_prefix, business_date):
    container_client = blob_service_client.get_container_client(container_name)
    file_list = os.listdir(local_directory)

    for file_name in file_list:
        if business_date in file_name:
            local_file_path = os.path.join(local_directory, file_name)
            blob_name = os.path.join(blob_prefix, file_name)
            blob_client = container_client.get_blob_client(blob_name)
            with open(local_file_path, "rb") as data:
                blob_client.upload_blob(data, overwrite=True)
            print(f"Uploaded {local_file_path} to {blob_name}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python upload_blob_log_output_files.py <app_container> <business_date>")
        sys.exit(1)

    container_name = sys.argv[1]
    business_date = sys.argv[2]

    downstream_feed = {
        "tba": ["pma"],
        "pma": ["crs"]
    }

    run_date = datetime.today().strftime('%Y%m%d')
    log_container = "banksimlogs"
    upload_files(log_container, local_logs_directory, f"{container_name}/", run_date)
    upload_files(container_name, local_output_directory, "data/output/", business_date)

    # Check if the container_name has a downstream feed and upload output files to the downstream's input directory
    if container_name in downstream_feed:
        for downstream_container in downstream_feed[container_name]:
            upload_files(downstream_container, local_output_directory, "data/input/", business_date)
