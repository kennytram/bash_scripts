#!/bin/bash

# Check if APP_FEATURE_NAME argument is provided
if [ -z "$1" ]; then
  echo "Error: APP_FEATURE_NAME argument is missing. Example: run_pma_load_referential_data"
  echo "Usage: $0 <APP_FEATURE_NAME>"
  exit 1
fi

# Parse command-line argument for APP_FEATURE_NAME
APP_FEATURE_NAME=$1

JOB_SCHEDULE_ID="$APP_FEATURE_NAME-schedule"
JSON_CONFIG="$APP_FEATURE_NAME.json"

# Global Configuration 
BATCH_ACCOUNT_NAME="opscobatch"
BATCH_ACCOUNT_KEY="HUyK1G9kmeS2f7dxST3MVikQ0r+3151h1ogIHW5TQ+AonWP9KsDvyYh2bFus0relBbcI6Q2uB00O+ABatnrWIQ=="  # Replace with your Batch account key
BATCH_ACCOUNT_URL="https://opscobatch.eastus.batch.azure.com"


# Delete the existing job schedule if it exists
az batch job-schedule delete --job-schedule-id $JOB_SCHEDULE_ID --account-name $BATCH_ACCOUNT_NAME --account-key $BATCH_ACCOUNT_KEY --account-endpoint $BATCH_ACCOUNT_URL --yes

# Create the new job schedule with the updated configuration
az batch job-schedule create --json-file $JSON_CONFIG --account-name $BATCH_ACCOUNT_NAME --account-key $BATCH_ACCOUNT_KEY --account-endpoint $BATCH_ACCOUNT_URL