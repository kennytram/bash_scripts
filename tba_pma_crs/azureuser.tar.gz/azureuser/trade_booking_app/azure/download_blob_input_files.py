import sys
import os
from azure.storage.blob import BlobServiceClient

# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))
from config import CONFIG

# Configuration
local_directory = "data/input"
blob_prefix = "data/input/"
account_name = CONFIG['azure_config']['account_name']
account_key = CONFIG['azure_config']['account_key']

connection_string = CONFIG['azure_config']['connection_string'].format(account_name=account_name, account_key=account_key)

# Initialize BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(connection_string)

def download_blobs(container_name, local_directory, blob_prefix, business_date):
    container_client = blob_service_client.get_container_client(container_name)
    blob_list = container_client.list_blobs(name_starts_with=blob_prefix)

    if not os.path.exists(local_directory):
        os.makedirs(local_directory)

    for blob in blob_list:
        if business_date in blob.name:
            blob_client = container_client.get_blob_client(blob.name)
            download_file_path = os.path.join(local_directory, os.path.basename(blob.name))
            with open(download_file_path, "wb") as download_file:
                download_file.write(blob_client.download_blob().readall())
            print(f"Downloaded {blob.name} to {download_file_path}")

if __name__ == "__main__":
    print("Usage: python download_blob_input_files.py <app_container> <business_date>")

    if len(sys.argv) == 3:
        container_name = sys.argv[1]
        business_date = sys.argv[2]
    else:
        print(f"ERROR: Missing app_container or business_date")
        sys.exit(1)

    download_blobs(container_name, local_directory, blob_prefix, business_date)
