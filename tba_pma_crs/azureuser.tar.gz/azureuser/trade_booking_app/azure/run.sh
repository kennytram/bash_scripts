#!/bin/bash

# Project file folder
folder="trade_booking_app"
app_trigram="tba"

# Check if APP_FEATURE_NAME argument is provided
if [ -z "$1" ]; then
  echo "Error: APP_FEATURE_NAME argument is missing. Example: run_tba_monitor_and_load_client_trades"
  echo "Usage: $0 <APP_FEATURE_NAME>"
  exit 1
fi

# Parse command-line argument for APP_FEATURE_NAME
APP_FEATURE_NAME=$1

# Unzip the project files
unzip $app_trigram.zip -d $folder

# Change directory to the project folder
cd $folder

# install requirements
# pip install -r requirements.txt

# Log the start of the script
echo "Starting to copy input files"

# current business date
business_date=$(python3 ./utils/get_business_date.py)

# Run the download_blob_input_files.py script to download input files
python3 azure/download_blob_input_files.py $app_trigram $business_date

# Check the exit status of the Python script
if [ $? -ne 0 ]; then
    echo "Error: download_blob_input_files.py failed."
fi

# Log the end of the script
echo "Finished copying input files"


# Run the launcher script (choose which part of the application to run in a container)
bash scripts/$APP_FEATURE_NAME.sh

return_code_main_script=$?

# Log the start of the script
echo "Starting to copy logs and output files"

# Run the download_blob_input_files.py script to download input files
python3 azure/upload_blob_log_output_files.py $app_trigram $business_date

# Check the exit status of the Python script
if [ $? -ne 0 ]; then
    echo "Error: upload_blob_log_output_files.py failed."
fi

# Log the end of the script
echo "Finished copying logs and output files"

# Check if the previous command failed
if [ $return_code_main_script -ne 0 ]; then
    echo "Error: The script scripts/$APP_FEATURE_NAME.sh failed."
    exit 1  # Exit the script with an error code
fi
