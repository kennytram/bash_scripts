import sys
import os
from azure.storage.blob import BlobServiceClient

# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))
from config import CONFIG

# Configuration
account_name = CONFIG['azure_config']['account_name']
account_key = CONFIG['azure_config']['account_key']

connection_string = CONFIG['azure_config']['connection_string'].format(account_name=account_name, account_key=account_key)

# Initialize BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(connection_string)

def move_blob(container_name, source_file_path, destination_file_path):
    container_client = blob_service_client.get_container_client(container_name)
    
    # Get blob clients
    source_blob_client = container_client.get_blob_client(source_file_path)
    destination_blob_client = container_client.get_blob_client(destination_file_path)
    
    # Start copy operation
    copy_operation = destination_blob_client.start_copy_from_url(source_blob_client.url)
    
    # Check the status of the copy operation
    props = destination_blob_client.get_blob_properties()
    while props.copy.status == 'pending':
        props = destination_blob_client.get_blob_properties()
    
    # Delete the source blob if copy is successful
    if props.copy.status == 'success':
        source_blob_client.delete_blob()
        print(f"Moved {source_file_path} to {destination_file_path}")
    else:
        print(f"Failed to move {source_file_path} to {destination_file_path}. Copy status: {props.copy.status}")

if __name__ == "__main__":
    print("Usage: python move_blob_input_files <container_name> <source_file_path> <destination_file_path>")

    if len(sys.argv) == 4:
        container_name = sys.argv[1]
        source_file_path = sys.argv[2]
        destination_file_path = sys.argv[3]
    else:
        print("ERROR: Missing container_name, source_file_path, or destination_file_path")
        sys.exit(1)

    move_blob(container_name, source_file_path, destination_file_path)
