import os
import subprocess
import time
import sys
import logging
from datetime import datetime

# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'utils'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))

from file_utils import initialize_log_file, list_input_files, move_trade_file_to_working_folder, move_trade_file_to_processed_folder
from config import CONFIG

def main(load_date, mode):
    # Configure Logging
    log_time_stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file_name =  CONFIG['log_files']['trade_monitoring'].format(timestamp=log_time_stamp)
    initialize_log_file(log_file_name)
    
    logging.info("Starting trade file monitoring...")

    while True:
        # Get list of all files in the input folder
        file_list = list_input_files()

        if file_list is not None:
            # Treat only the csv trade files of the matching the load date
            csv_files = [file for file in file_list if file.endswith('.csv') and 'trades' in file and load_date in file]
            if not csv_files:
                logging.info(f"No CSV trade files of the load date {load_date} found in the input folder.")
                #time.sleep(10)  
                #continue # Wait before checking again
                break # break and finishes after 1 check
            else:
                # Process each csv trade file
                for file_name in csv_files:
                    try:
                        # Move the working file to the working folder
                        move_trade_file_to_working_folder(mode, file_name)

                        # Call the trade load program
                        logging.info(f"Calling Load Client Trade process.")
                        
                        # Get the directory of the script
                        current_dir = os.path.dirname(os.path.abspath(__file__))
                        
                        # Construct the full path to load_client_trades.py
                        script_path = os.path.join(current_dir, "load_client_trades.py")

                        result = subprocess.run(
                            ["python3", script_path, file_name],
                            capture_output=True,
                            text=True,
                            timeout=120
                        )

                        if result.returncode != 0:
                            logging.error(f"Error calling Load Client Trade process for {file_name}. Check logs for more details") 
                            logging.error(f"Exit status: {result.stdout}")
                            exit(1)
                        else:
                            logging.info(f"Load Client Trade process executed for {file_name}.")
                            
                            # Move the processed file to the processed folder
                            move_trade_file_to_processed_folder(mode, file_name)

                    except Exception as e:
                        logging.error(f"Error: {e}")
                        exit(1)


if __name__ == '__main__':    
    print("Usage: python monitor_and_load_client_trades.py <load_date> <mode> (local/remote)")
    
    if len(sys.argv) == 3:
       load_date = sys.argv[1]
       mode = sys.argv[2]
       print(f"The program will run with the user's date:{load_date} and mode:{mode}")
    else:
        load_date = datetime.today().strftime('%Y%m%d')
        mode = 'local'
        print(f"The program will run with today's date:{load_date} and mode:{mode}")
           
    main(load_date, mode)
