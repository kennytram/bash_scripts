import os
import sys
import logging
from datetime import datetime

# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'utils'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))

from db_utils import extract_data
from file_utils import write_csv_file, initialize_log_file
from config import CONFIG


def main(extract_date):
    try:
        # Initialize log file
        log_time_stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file_name =  CONFIG['log_files']['eod_extract_trades'].format(timestamp=log_time_stamp)
        initialize_log_file(log_file_name)

        logging.info("Starting EOD trade report generation...")
        
        # Build trades extract query
        query = f"""
            SELECT {', '.join(CONFIG['fields_to_extract']['eod_trades'])}
            FROM TradeBooking.Trades
            WHERE TradeDate = :extract_date
        """

        # Run trades extract Query
        trades_data = extract_data(query, params={'extract_date': extract_date})
        if trades_data is not None:
            output_file_name = CONFIG['output_files']['eod_trades'].format(date=extract_date)
            output_file_path = os.path.join(CONFIG['output_files']['local_output_folder'], output_file_name)
            write_csv_file(trades_data, output_file_path)

        logging.info("EOD trade report generation completed")
    except Exception as e:
        print(f"An error occurred: {e}")
        exit(1)


if __name__ == '__main__':
    print("Usage: python eod_extract_trades.py <extract_date>")

    if len(sys.argv) == 2:
       extract_date = sys.argv[1]
       print(f"The program will run with the user's date:{extract_date}")
    else:
        extract_date = datetime.today().strftime('%Y%m%d')
        print(f"The program will run with today's date:{extract_date}")
           
    main(extract_date)