import pandas as pd
import os
import sys
import logging
from datetime import datetime

# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'utils'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))

from file_utils import initialize_log_file, read_and_load_file_to_db
from config import CONFIG

def main(load_date):
    try:
        # Configure Logging
        log_time_stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file_name =  CONFIG['log_files']['load_position_data'].format(timestamp=log_time_stamp)
        initialize_log_file(log_file_name)

        logging.info("Starting to load positions data...")

        for table, attributes in CONFIG['load_position_data'].items():
            file_name = attributes['file']
            loading_type = attributes['loading_type']
            read_and_load_file_to_db(load_date, file_name, table, 'TradeBooking', loading_type)
        
        logging.info("Finished loading positions data.")
    except Exception as e:
        print(f"An error occurred: {e}")
        exit(1)



if __name__ == '__main__':
    print("Usage: python load_sod_positions.py <load_date>")

    if len(sys.argv) == 2:
       load_date = sys.argv[1]
       print(f"The program will run with the user's date:{load_date}")
    else:
        load_date = datetime.today().strftime('%Y%m%d')
        print(f"The program will run with today's date:{load_date}")
           
    main(load_date)
