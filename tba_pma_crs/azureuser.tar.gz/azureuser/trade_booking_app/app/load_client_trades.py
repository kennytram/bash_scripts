import pandas as pd
import os
import sys
import logging
from datetime import datetime

# Add the folder paths to the sys.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'utils'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'config'))

from db_utils import insert_trades_to_db, is_client_authorized
from file_utils import initialize_log_file, read_csv_file, parse_filename
from sanity_checks import sanity_check, sanity_check_repo, sanity_check_loan
from config import CONFIG


def main(file_name):

    # Parse the file name to get the client code, trade type, and trade date, and file number
    client_code, trade_type, trade_date, file_number = parse_filename(file_name)
    
    # Initialize log file
    log_time_stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file_name =  CONFIG['log_files']['load_client_trades'].format(client=client_code, trade_type=trade_type, date=trade_date, file_number=file_number, timestamp=log_time_stamp)
    initialize_log_file(log_file_name)
    logging.info(f"Parsed client code: {client_code}, trade type: {trade_type}, trade date: {trade_date}, file_number: {file_number}.")

    # Local file path to save the CSV file
    local_csv_file_path = os.path.abspath(os.path.join(CONFIG['local_paths']['local_working_folder'], file_name))
    
    logging.info("Starting trade processing.")

    # Check if the client is authorized (functional error)
    if not is_client_authorized(client_code, trade_date):
        logging.error(f"ErrorCode: 112, Client '{client_code}' is not authorized to submit trades for business date {trade_date}.")
        return
    
    # Load client trades CSV file
    trades_data = read_csv_file(local_csv_file_path)
    
    # Perform sanity checks
    if trade_type == 'trades':
        table = "Trades"
        valid_data = sanity_check(trades_data, client_code, trade_date)
    elif trade_type == 'repotrades':
        table = "RepoTrades"
        valid_data = sanity_check_repo(trades_data, client_code, trade_date)
    elif trade_type == 'loantrades':
        table = "LoanTrades"
        valid_data = sanity_check_loan(trades_data, client_code, trade_date)
    else:
        logging.error(f"ErrorCode: 113, Unknown trade type: {trade_type}")
        exit(1)
    
    if not valid_data.empty:
        logging.info("Insert data into the database")
        insert_trades_to_db(valid_data, table, "TradeBooking")
        
    logging.info("Finished loading trades.")


if __name__ == '__main__':
    print("Usage: python load_client_trades.py <trade_file_name>")

    if len(sys.argv) != 2:
        sys.exit(1)
    else:
        trade_file_name = sys.argv[1]

    main(trade_file_name)
